@echo off
REM Arranca a ponte Muse 2 -> OSC. Argumentos extra passam para o script, ex.:
REM   start_bridge.bat --simulate
REM   start_bridge.bat --debug --average
cd /d %~dp0
python muse_bridge.py %*
pause
