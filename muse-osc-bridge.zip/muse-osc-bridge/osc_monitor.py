#!/usr/bin/env python3
"""
osc_monitor.py — mostra o que está a chegar por OSC (endereço, taxa em Hz, últimos valores).
Útil para confirmar a ponte antes de abrir o TouchDesigner.

    python osc_monitor.py                    # escuta na porta 5000
    python osc_monitor.py --filter /muse/elements
"""

import argparse
import threading
import time
from collections import defaultdict

from pythonosc.dispatcher import Dispatcher
from pythonosc.osc_server import ThreadingOSCUDPServer

counts = defaultdict(int)
last = {}
lock = threading.Lock()


def handler(addr, *args):
    with lock:
        counts[addr] += 1
        last[addr] = args


def fmt(v):
    return f"{v:8.3f}" if isinstance(v, float) else str(v)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ip", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=5000)
    ap.add_argument("--filter", default="", help="só endereços começados por este prefixo")
    ap.add_argument("--seconds", type=float, default=0, help="termina ao fim de N s (0 = nunca)")
    args = ap.parse_args()

    disp = Dispatcher()
    disp.set_default_handler(handler)
    server = ThreadingOSCUDPServer((args.ip, args.port), disp)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f"A escutar OSC em {args.ip}:{args.port}  (Ctrl+C para sair)")

    t0 = time.time()
    try:
        while True:
            time.sleep(1.0)
            with lock:
                snap = dict(counts)
                vals = dict(last)
                counts.clear()
            print(f"\n--- {time.strftime('%H:%M:%S')} ---")
            for addr in sorted(vals):
                if not addr.startswith(args.filter):
                    continue
                v = " ".join(fmt(x) for x in vals[addr][:5])
                print(f"{addr:38s} {snap.get(addr, 0):4d} Hz  {v}")
            if args.seconds and time.time() - t0 >= args.seconds:
                break
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()


if __name__ == "__main__":
    main()
